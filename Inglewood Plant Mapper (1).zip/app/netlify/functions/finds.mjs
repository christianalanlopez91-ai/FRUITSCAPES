import { getStore } from "@netlify/blobs";

const CORS = {
  "access-control-allow-origin": "*",
  "access-control-allow-methods": "GET,POST,OPTIONS",
  "access-control-allow-headers": "content-type"
};

export default async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { status: 204, headers: CORS });
  const store = getStore("fruitscape-finds");
  const photos = getStore("fruitscape-photos");

  if (req.method === "GET") {
    const list = (await store.get("index", { type: "json" })) || [];
    return Response.json(list, { headers: CORS });
  }

  if (req.method === "POST") {
    let body;
    try { body = await req.json(); } catch { return new Response("Bad JSON", { status: 400, headers: CORS }); }
    if (!body || typeof body.id !== "string" || typeof body.lat !== "number" || typeof body.lng !== "number") {
      return new Response("Missing id/lat/lng", { status: 400, headers: CORS });
    }
    const list = (await store.get("index", { type: "json" })) || [];
    const prev = list.find(f => f.id === body.id);
    const rec = {
      id: body.id,
      name: String(body.name || "").slice(0, 120),
      cat: ["Fruit", "Veg", "Herb", "Other"].includes(body.cat) ? body.cat : "Other",
      loc: String(body.loc || "").slice(0, 200),
      months: Array.isArray(body.months) ? body.months.filter(n => Number.isInteger(n) && n >= 1 && n <= 12) : [],
      access: String(body.access || "").slice(0, 200),
      notes: String(body.notes || "").slice(0, 2000),
      lat: body.lat, lng: body.lng,
      created: Number.isFinite(body.created) ? body.created : Date.now(),
      visited: Number.isFinite(body.visited) ? body.visited : null,
      hasPhoto: prev ? prev.hasPhoto : false
    };
    if (typeof body.photo === "string" && body.photo.startsWith("data:")) {
      const comma = body.photo.indexOf(",");
      const contentType = (body.photo.slice(5, comma).split(";")[0]) || "image/jpeg";
      const bytes = Uint8Array.from(atob(body.photo.slice(comma + 1)), c => c.charCodeAt(0));
      await photos.set(rec.id, bytes, { metadata: { contentType } });
      rec.hasPhoto = true;
    }
    const i = list.findIndex(f => f.id === rec.id);
    if (i >= 0) list[i] = rec; else list.push(rec);
    await store.setJSON("index", list);
    return Response.json(rec, { headers: CORS });
  }

  return new Response("Method not allowed", { status: 405, headers: CORS });
};

export const config = { path: "/api/finds" };
