import { getStore } from "@netlify/blobs";

const CORS = { "access-control-allow-origin": "*", "access-control-allow-methods": "DELETE,OPTIONS" };

export default async (req, context) => {
  if (req.method === "OPTIONS") return new Response(null, { status: 204, headers: CORS });
  if (req.method !== "DELETE") return new Response("Method not allowed", { status: 405, headers: CORS });
  const id = context.params.id;
  const store = getStore("fruitscape-finds");
  const photos = getStore("fruitscape-photos");
  const list = (await store.get("index", { type: "json" })) || [];
  await store.setJSON("index", list.filter(f => f.id !== id));
  try { await photos.delete(id); } catch {}
  return Response.json({ ok: true }, { headers: CORS });
};

export const config = { path: "/api/finds/:id" };
