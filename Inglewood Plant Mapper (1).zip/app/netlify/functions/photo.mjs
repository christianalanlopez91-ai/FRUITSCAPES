import { getStore } from "@netlify/blobs";

export default async (req, context) => {
  const id = context.params.id;
  const photos = getStore("fruitscape-photos");
  let entry;
  try { entry = await photos.getWithMetadata(id, { type: "arrayBuffer" }); } catch { entry = null; }
  if (!entry || !entry.data) return new Response("Not found", { status: 404 });
  return new Response(entry.data, {
    headers: {
      "content-type": (entry.metadata && entry.metadata.contentType) || "image/jpeg",
      "cache-control": "public, max-age=31536000, immutable"
    }
  });
};

export const config = { path: "/api/photo/:id" };
